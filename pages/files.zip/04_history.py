# pages/04_history.py
import streamlit as st
import pandas as pd
import io
from utils.auth import require_login, is_role
from utils.db import fetch_history

st.set_page_config(
    page_title="WMS V2.0 — 입출고 이력",
    page_icon="📋",
    layout="wide"
)

require_login()

user      = st.session_state.user
user_role = user["role"]
user_name = user["name"]

# ── CSS ───────────────────────────────────────────────────────────────────
st.markdown("""
<style>
section[data-testid="stSidebar"] { width:165px!important; min-width:165px!important; }
section[data-testid="stSidebar"] * { font-size:12px!important; }
section[data-testid="stSidebar"] button {
    padding:3px 6px!important; min-height:28px!important; height:28px!important;
}
.main .block-container { padding-top:2.8rem!important; overflow:visible!important; }
.main { overflow:visible!important; }
h2 { line-height:1.8!important; padding:6px 0 2px 0!important; overflow:visible!important; }
hr { margin:3px 0 6px 0!important; }
div[data-testid="column"] { padding:0px 2px!important; }
[data-testid="stDataEditor"] th {
    background-color:#e8edf5!important;
    color:#1a237e!important;
    font-weight:700!important;
    font-size:12px!important;
    border-bottom:2px solid #7986cb!important;
    white-space:nowrap!important;
}
[data-testid="stDataEditor"] td { font-size:13px!important; padding:2px 8px!important; }
</style>
""", unsafe_allow_html=True)

# ── 사이드바 ──────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown(f"**{user_name}**")
    st.caption(f"{user_role} · {user.get('center','')}")
    st.divider()
    if st.button("📦 창고 목록", use_container_width=True):
        st.switch_page("pages/02_warehouse.py")
    if st.button("🚚 이동 신청 현황", use_container_width=True):
        st.switch_page("pages/03_transfers.py")
    if is_role("admin"):
        if st.button("⚙️ 관리자", use_container_width=True):
            st.switch_page("pages/05_admin.py")
    if st.button("👤 마이페이지", use_container_width=True):
        st.switch_page("pages/06_mypage.py")
    if st.button("🚪 로그아웃", use_container_width=True):
        st.session_state.user = None
        st.switch_page("pages/01_login.py")

# ── 타이틀 ────────────────────────────────────────────────────────────────
st.markdown("## 📋 입출고 이력")
st.divider()

# ── 필터 ─────────────────────────────────────────────────────────────────
fc1, fc2, fc3 = st.columns([2, 2, 1])
with fc1:
    filter_action = st.selectbox(
        "작업 유형",
        ["전체", "입고(in)", "출고(out)", "이동(transfer)"],
        label_visibility="collapsed"
    )
with fc2:
    filter_search = st.text_input(
        "검색", placeholder="자재명 / 작업자 / 사유 검색...",
        label_visibility="collapsed"
    )
with fc3:
    filter_limit = st.selectbox(
        "표시 건수", [100, 200, 500, 1000],
        label_visibility="collapsed"
    )

action_map = {
    "전체": None,
    "입고(in)": "in",
    "출고(out)": "out",
    "이동(transfer)": "transfer"
}
action_filter = action_map[filter_action]

# ── 데이터 로드 ───────────────────────────────────────────────────────────
raw = fetch_history(action_type=action_filter, limit=filter_limit)

if not raw:
    st.info("이력이 없습니다.")
    st.stop()

# ── 데이터 가공 ───────────────────────────────────────────────────────────
rows = []
for h in raw:
    item_info   = h.get("warehouse", {}) or {}
    actor_info  = h.get("users", {})    or {}
    action_label = {"in":"📥 입고","out":"📤 출고","transfer":"🚚 이동"}.get(
        h.get("action_type",""), h.get("action_type","")
    )
    route = ""
    if h.get("from_center") and h.get("to_center"):
        route = f"{h['from_center']} → {h['to_center']}"

    rows.append({
        "일시":      (h.get("acted_at","") or "")[:16].replace("T"," "),
        "작업자":    actor_info.get("name",""),
        "자재명":    item_info.get("item_name",""),
        "센터":      item_info.get("location",""),
        "작업유형":  action_label,
        "수량":      h.get("quantity",0),
        "변경전":    h.get("snapshot_qty_before",""),
        "변경후":    h.get("snapshot_qty_after",""),
        "이동경로":  route,
        "사유":      h.get("reason",""),
    })

df_hist = pd.DataFrame(rows)

# ── 검색 필터 ─────────────────────────────────────────────────────────────
if filter_search:
    mask = (
        df_hist["자재명"].str.contains(filter_search, case=False, na=False) |
        df_hist["작업자"].str.contains(filter_search, case=False, na=False) |
        df_hist["사유"].str.contains(filter_search, case=False, na=False)
    )
    df_hist = df_hist[mask]

st.caption(f"총 {len(df_hist)}건")

# ── 테이블 표시 ───────────────────────────────────────────────────────────
st.dataframe(
    df_hist,
    use_container_width=True,
    hide_index=True,
    column_config={
        "일시":     st.column_config.TextColumn("일시",     width=130),
        "작업자":   st.column_config.TextColumn("작업자",   width=80),
        "자재명":   st.column_config.TextColumn("자재명",   width=200),
        "센터":     st.column_config.TextColumn("센터",     width=90),
        "작업유형": st.column_config.TextColumn("작업유형", width=90),
        "수량":     st.column_config.NumberColumn("수량",   width=60),
        "변경전":   st.column_config.NumberColumn("변경전", width=60),
        "변경후":   st.column_config.NumberColumn("변경후", width=60),
        "이동경로": st.column_config.TextColumn("이동경로", width=160),
        "사유":     st.column_config.TextColumn("사유",     width=200),
    }
)

# ── 엑셀 다운로드 ─────────────────────────────────────────────────────────
buf = io.BytesIO()
with pd.ExcelWriter(buf, engine="openpyxl") as writer:
    df_hist.to_excel(writer, index=False, sheet_name="이력")
buf.seek(0)

st.download_button(
    "⬇️ 이력 엑셀 다운로드",
    data=buf,
    file_name="WMS_입출고이력.xlsx",
    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    use_container_width=True
)
