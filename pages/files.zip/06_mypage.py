# pages/06_mypage.py
import streamlit as st
from utils.auth import require_login, verify_password, hash_password, is_role
from utils.db import get_supabase
from utils.routing import CENTERS

st.set_page_config(
    page_title="WMS V2.0 — 마이페이지",
    page_icon="👤",
    layout="centered"
)

require_login()

user      = st.session_state.user
user_id   = user["id"]
user_name = user["name"]
user_role = user["role"]
sb        = get_supabase()

# ── CSS ───────────────────────────────────────────────────────────────────
st.markdown("""
<style>
section[data-testid="stSidebar"] { width:165px!important; min-width:165px!important; }
section[data-testid="stSidebar"] * { font-size:12px!important; }
section[data-testid="stSidebar"] button {
    padding:3px 6px!important; min-height:28px!important; height:28px!important;
}
.main .block-container {
    padding-top:2.8rem!important;
    max-width:520px!important;
    overflow:visible!important;
}
.main { overflow:visible!important; }
h2 { line-height:1.8!important; padding:6px 0 2px 0!important; overflow:visible!important; }
hr { margin:3px 0 6px 0!important; }
</style>
""", unsafe_allow_html=True)

# ── 사이드바 ──────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown(f"**{user_name}**")
    st.caption(f"{user_role} · {user.get('center','')}")
    st.divider()
    if st.button("📦 창고 목록", use_container_width=True):
        st.switch_page("pages/02_warehouse.py")
    if st.button("🚚 이동 신청 현황", use_container_width=True):
        st.switch_page("pages/03_transfers.py")
    if st.button("📋 입출고 이력", use_container_width=True):
        st.switch_page("pages/04_history.py")
    if is_role("admin"):
        if st.button("⚙️ 관리자", use_container_width=True):
            st.switch_page("pages/05_admin.py")
    if st.button("🚪 로그아웃", use_container_width=True):
        st.session_state.user = None
        st.switch_page("pages/01_login.py")

# ── 타이틀 ────────────────────────────────────────────────────────────────
st.markdown("## 👤 마이페이지")
st.divider()

ROLE_LABELS = {
    "admin":     "관리자",
    "materials": "자재파트",
    "manager":   "센터장",
    "user":      "사용자",
    "guest":     "게스트",
}

tab_info, tab_pw = st.tabs(["📋 내 정보 수정", "🔑 비밀번호 변경"])

# ── [탭 1] 내 정보 수정 ───────────────────────────────────────────────────
with tab_info:
    st.subheader("내 정보")

    # 읽기 전용 정보
    st.info(
        f"**아이디:** {user.get('username','')}  |  "
        f"**권한:** {ROLE_LABELS.get(user_role, user_role)}  |  "
        f"**승인:** {'✅' if user.get('is_approved') else '⏳'}"
    )

    with st.form("form_myinfo"):
        new_name   = st.text_input("이름 *", value=user.get("name",""))
        new_email  = st.text_input("회사 이메일 *", value=user.get("email",""))
        new_phone  = st.text_input("연락처", value=user.get("phone","") or "")
        new_center = st.selectbox(
            "소속 센터",
            CENTERS,
            index=CENTERS.index(user.get("center", CENTERS[0]))
            if user.get("center") in CENTERS else 0
        )
        submitted = st.form_submit_button(
            "저장", use_container_width=True, type="primary"
        )

    if submitted:
        if not new_name or not new_email:
            st.warning("이름과 이메일은 필수입니다.")
        else:
            try:
                sb.table("users").update({
                    "name":   new_name,
                    "email":  new_email,
                    "phone":  new_phone,
                    "center": new_center,
                }).eq("id", user_id).execute()

                # 세션 즉시 갱신
                st.session_state.user["name"]   = new_name
                st.session_state.user["email"]  = new_email
                st.session_state.user["phone"]  = new_phone
                st.session_state.user["center"] = new_center
                st.success("정보가 업데이트됐습니다!")
            except Exception as e:
                st.error(f"저장 오류: {e}")

# ── [탭 2] 비밀번호 변경 ──────────────────────────────────────────────────
with tab_pw:
    st.subheader("비밀번호 변경")

    with st.form("form_pw"):
        current_pw = st.text_input("현재 비밀번호", type="password")
        new_pw     = st.text_input("새 비밀번호 (6자 이상)", type="password")
        new_pw2    = st.text_input("새 비밀번호 확인", type="password")
        pw_submit  = st.form_submit_button(
            "변경", use_container_width=True, type="primary"
        )

    if pw_submit:
        if not all([current_pw, new_pw, new_pw2]):
            st.warning("모든 항목을 입력하세요.")
        elif new_pw != new_pw2:
            st.error("새 비밀번호가 일치하지 않습니다.")
        elif len(new_pw) < 6:
            st.error("비밀번호는 6자 이상이어야 합니다.")
        else:
            res = sb.table("users").select("password_hash").eq(
                "id", user_id
            ).single().execute()
            if not verify_password(current_pw, res.data["password_hash"]):
                st.error("현재 비밀번호가 올바르지 않습니다.")
            else:
                sb.table("users").update({
                    "password_hash": hash_password(new_pw)
                }).eq("id", user_id).execute()
                st.success("비밀번호가 변경됐습니다. 다음 로그인부터 적용됩니다.")
