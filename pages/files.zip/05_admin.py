# pages/05_admin.py
import streamlit as st
from utils.auth import require_role
from utils.db import get_supabase
from utils.routing import CENTERS

st.set_page_config(
    page_title="WMS V2.0 — 관리자",
    page_icon="⚙️",
    layout="wide"
)

require_role("admin")

user      = st.session_state.user
user_name = user["name"]
sb        = get_supabase()

# ── CSS ───────────────────────────────────────────────────────────────────
st.markdown("""
<style>
section[data-testid="stSidebar"] { width:165px!important; min-width:165px!important; }
section[data-testid="stSidebar"] * { font-size:12px!important; }
section[data-testid="stSidebar"] button {
    padding:3px 6px!important; min-height:28px!important; height:28px!important;
}
.main .block-container { padding-top:2.8rem!important; overflow:visible!important; }
.main { overflow:visible!important; }
h2 { line-height:1.8!important; padding:6px 0 2px 0!important; overflow:visible!important; }
hr { margin:3px 0 6px 0!important; }
div[data-testid="column"] { padding:0px 2px!important; }
</style>
""", unsafe_allow_html=True)

# ── 사이드바 ──────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown(f"**{user_name}**")
    st.caption("admin")
    st.divider()
    if st.button("📦 창고 목록", use_container_width=True):
        st.switch_page("pages/02_warehouse.py")
    if st.button("🚚 이동 신청 현황", use_container_width=True):
        st.switch_page("pages/03_transfers.py")
    if st.button("📋 입출고 이력", use_container_width=True):
        st.switch_page("pages/04_history.py")
    if st.button("👤 마이페이지", use_container_width=True):
        st.switch_page("pages/06_mypage.py")
    if st.button("🚪 로그아웃", use_container_width=True):
        st.session_state.user = None
        st.switch_page("pages/01_login.py")

# ── 타이틀 ────────────────────────────────────────────────────────────────
st.markdown("## ⚙️ 관리자 페이지")
st.divider()

tab_users, tab_pending = st.tabs(["👥 전체 회원 목록", "✅ 가입 승인 대기"])

# ── 권한 옵션 ─────────────────────────────────────────────────────────────
ROLE_OPTIONS = ["admin", "materials", "manager", "user", "guest"]
ROLE_LABELS  = {
    "admin":     "관리자",
    "materials": "자재파트",
    "manager":   "센터장",
    "user":      "사용자",
    "guest":     "게스트",
}

# ── [탭 1] 전체 회원 목록 ─────────────────────────────────────────────────
with tab_users:
    st.subheader("전체 회원 목록")
    res   = sb.table("users").select("*").order("created_at", desc=True).execute()
    users = res.data or []

    if not users:
        st.info("등록된 회원이 없습니다.")
    else:
        for u in users:
            with st.container(border=True):
                c1, c2, c3, c4 = st.columns([2, 2, 2, 2])

                # 이름 / 아이디
                c1.markdown(f"**{u['name']}**")
                c1.caption(f"ID: {u.get('username','')} · {u.get('center','')}")

                # 이메일 / 연락처
                c2.write(u.get("email",""))
                c2.caption(u.get("phone",""))

                # 권한 변경
                current_role = u.get("role","guest")
                if u["id"] == user["id"]:
                    c3.write(f"**{ROLE_LABELS.get(current_role, current_role)}** (본인)")
                else:
                    new_role = c3.selectbox(
                        "권한",
                        ROLE_OPTIONS,
                        index=ROLE_OPTIONS.index(current_role),
                        key=f"role_{u['id']}",
                        format_func=lambda x: ROLE_LABELS.get(x, x),
                        label_visibility="collapsed"
                    )
                    if new_role != current_role:
                        if c3.button("저장", key=f"save_role_{u['id']}",
                                     use_container_width=True):
                            sb.table("users").update(
                                {"role": new_role}
                            ).eq("id", u["id"]).execute()
                            st.success(f"{u['name']} 권한 변경 완료!")
                            st.rerun()

                # 승인 상태
                is_approved = u.get("is_approved", False)
                c4.write("✅ 승인됨" if is_approved else "⏳ 미승인")
                if u["id"] != user["id"]:
                    if is_approved:
                        if c4.button("승인 취소", key=f"unapprove_{u['id']}",
                                     use_container_width=True):
                            sb.table("users").update(
                                {"is_approved": False}
                            ).eq("id", u["id"]).execute()
                            st.rerun()
                    else:
                        if c4.button("✅ 승인", key=f"approve_{u['id']}",
                                     type="primary", use_container_width=True):
                            sb.table("users").update(
                                {"is_approved": True}
                            ).eq("id", u["id"]).execute()
                            st.success(f"{u['name']} 승인 완료!")
                            st.rerun()

# ── [탭 2] 가입 승인 대기 ─────────────────────────────────────────────────
with tab_pending:
    st.subheader("승인 대기 중인 회원")
    res     = sb.table("users").select("*").eq(
        "is_approved", False
    ).order("created_at").execute()
    pending = res.data or []

    if not pending:
        st.success("승인 대기 중인 회원이 없습니다.")
    else:
        for u in pending:
            with st.container(border=True):
                c1, c2, c3 = st.columns([3, 3, 2])
                c1.markdown(f"**{u['name']}**")
                c1.caption(
                    f"ID: {u.get('username','')} · "
                    f"{ROLE_LABELS.get(u.get('role','guest'), u.get('role',''))} · "
                    f"{u.get('center','')}"
                )
                c2.write(u.get("email",""))
                c2.caption(u.get("phone",""))
                with c3:
                    if st.button("✅ 승인", key=f"pa_{u['id']}",
                                 type="primary", use_container_width=True):
                        sb.table("users").update(
                            {"is_approved": True}
                        ).eq("id", u["id"]).execute()
                        st.success(f"{u['name']} 승인 완료!")
                        st.rerun()
                    if st.button("❌ 거절/삭제", key=f"pd_{u['id']}",
                                 use_container_width=True):
                        sb.table("users").delete().eq(
                            "id", u["id"]
                        ).execute()
                        st.rerun()
