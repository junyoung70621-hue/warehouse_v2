# pages/03_transfers.py
import streamlit as st
import pandas as pd
from utils.auth import require_login, is_role
from utils.db import (
    fetch_transfers, approve_transfer,
    clear_transfer_cache, get_supabase
)
from utils.routing import can_approve

st.set_page_config(
    page_title="WMS V2.0 — 이동 신청",
    page_icon="🚚",
    layout="wide"
)

require_login()

user      = st.session_state.user
user_id   = user["id"]
user_role = user["role"]
user_name = user["name"]

# ── CSS ───────────────────────────────────────────────────────────────────
st.markdown("""
<style>
section[data-testid="stSidebar"] { width:165px!important; min-width:165px!important; }
section[data-testid="stSidebar"] * { font-size:12px!important; }
section[data-testid="stSidebar"] button {
    padding:3px 6px!important; min-height:28px!important; height:28px!important;
}
.main .block-container { padding-top:2.8rem!important; overflow:visible!important; }
.main { overflow:visible!important; }
h2 { line-height:1.8!important; padding:6px 0 2px 0!important; overflow:visible!important; }
hr { margin:3px 0 6px 0!important; }
div[data-testid="column"] { padding:0px 2px!important; }
</style>
""", unsafe_allow_html=True)

# ── 사이드바 ──────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown(f"**{user_name}**")
    st.caption(f"{user_role} · {user.get('center','')}")
    st.divider()
    if st.button("📦 창고 목록", use_container_width=True):
        st.switch_page("pages/02_warehouse.py")
    if st.button("📋 입출고 이력", use_container_width=True):
        st.switch_page("pages/04_history.py")
    if is_role("admin"):
        if st.button("⚙️ 관리자", use_container_width=True):
            st.switch_page("pages/05_admin.py")
    if st.button("👤 마이페이지", use_container_width=True):
        st.switch_page("pages/06_mypage.py")
    if st.button("🚪 로그아웃", use_container_width=True):
        st.session_state.user = None
        st.switch_page("pages/01_login.py")

# ── 타이틀 ────────────────────────────────────────────────────────────────
st.markdown("## 🚚 센터 간 이동 신청 현황")
st.divider()

# ── 탭 구성 ───────────────────────────────────────────────────────────────
tab_pending, tab_approved, tab_rejected, tab_all = st.tabs([
    "⏳ 대기중", "✅ 승인됨", "❌ 거절됨", "📋 전체"
])


def render_transfers(status_filter: str = None):
    data = fetch_transfers(status_filter)
    if not data:
        st.info("해당 신청 내역이 없습니다.")
        return

    for tr in data:
        # 자재명, 신청자명 파싱
        item_name = tr.get("warehouse", {})
        if isinstance(item_name, dict):
            item_name = item_name.get("item_name", "알 수 없음")

        requester_name = tr.get("users", {})
        if isinstance(requester_name, dict):
            requester_name = requester_name.get("name", "알 수 없음")

        status = tr.get("status", "")
        status_label = {
            "pending":   "⏳ 대기중",
            "approved":  "✅ 승인됨",
            "rejected":  "❌ 거절됨",
            "cancelled": "🚫 취소됨"
        }.get(status, status)

        with st.container(border=True):
            c1, c2, c3, c4, c5 = st.columns([3, 2, 2, 1.5, 2])

            # 자재명 + 신청자
            c1.markdown(f"**{item_name}**")
            c1.caption(f"신청자: {requester_name}")

            # 경로
            c2.write(f"📤 {tr.get('from_center','')}")
            c2.write(f"📥 {tr.get('to_center','')}")

            # 수량
            c3.metric("수량", tr.get("quantity", 0))

            # 상태
            c4.write(status_label)

            # 액션 버튼
            with c5:
                # 승인 권한자: 대기중 건 승인/거절 가능
                if status == "pending" and can_approve(user_role):
                    if st.button(
                        "✅ 승인",
                        key=f"approve_{status_filter}_{tr['id']}",
                        type="primary",
                        use_container_width=True
                    ):
                        if approve_transfer(tr["id"], user_id):
                            st.success("승인 완료! 재고가 자동 처리됐습니다.")
                            clear_transfer_cache()
                            st.rerun()

                    if st.button(
                        "❌ 거절",
                        key=f"reject_{status_filter}_{tr['id']}",
                        use_container_width=True
                    ):
                        sb = get_supabase()
                        sb.table("transfers").update({
                            "status":       "rejected",
                            "processed_at": "now()"
                        }).eq("id", tr["id"]).execute()
                        clear_transfer_cache()
                        st.rerun()

                # 신청자 본인: 대기중 건 취소 가능
                elif (status == "pending"
                      and tr.get("requester_id") == user_id
                      and not can_approve(user_role)):
                    if st.button(
                        "🚫 취소",
                        key=f"cancel_{status_filter}_{tr['id']}",
                        use_container_width=True
                    ):
                        sb = get_supabase()
                        sb.table("transfers").update({
                            "status":       "cancelled",
                            "processed_at": "now()"
                        }).eq("id", tr["id"]).execute()
                        clear_transfer_cache()
                        st.rerun()

            # 신청 일시
            requested_at = tr.get("requested_at", "")
            if requested_at:
                st.caption(f"신청일: {requested_at[:16].replace('T',' ')}")

            # 처리 일시 (승인/거절 건)
            processed_at = tr.get("processed_at")
            if processed_at:
                st.caption(f"처리일: {processed_at[:16].replace('T',' ')}")


with tab_pending:
    render_transfers("pending")

with tab_approved:
    render_transfers("approved")

with tab_rejected:
    render_transfers("rejected")

with tab_all:
    render_transfers(None)
